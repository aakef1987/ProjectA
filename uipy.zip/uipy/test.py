
import openpyxl as xl
#a=xl.load_workbook('new.xlsx')
a=xl.Workbook
a.create_sheet(title='new9')
sheet=a.active
sheet.cell(row=3, column=2, value=10)
sheet.cell(row=2,column=1,value="akef")

a.save('new.xlsx')